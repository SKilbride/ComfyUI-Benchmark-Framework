import sys
import subprocess
import importlib.util

def check_and_install(package_name, import_name):
    # 1. Check if module is already importable
    try:
        spec = importlib.util.find_spec(import_name)
    except (ModuleNotFoundError, ImportError, ValueError):
        # ValueError can happen if import_name is invalid
        # ModuleNotFoundError happens if parent package (e.g. 'google') is missing
        spec = None

    if spec is not None:
        print(f"[pre.py] '{package_name}' is already installed. Skipping.")
        return

    # 2. Install if missing
    print(f"[pre.py] '{package_name}' not found. Installing...")
    try:
        subprocess.check_call([
            sys.executable, "-m", "pip", "install", package_name
        ])
        print(f"[pre.py] Successfully installed '{package_name}'.")
        
        # 3. SIGNAL RESTART
        # This string tells the benchmark framework to trigger the restart dialog
        print("BENCHMARK_RESTART_REQUIRED")
        
    except subprocess.CalledProcessError as e:
        print(f"[pre.py] Failed to install '{package_name}': {e}")
        sys.exit(1)

if __name__ == "__main__":
    # protobuf is the package, google.protobuf is the import
    check_and_install("protobuf", "google.protobuf")